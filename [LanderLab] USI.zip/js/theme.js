var ivr_phone = "877-959-9874";
var website_phone = "877-959-9874";
//var website_address = "244 S Randall Road Suite 1010, Elgin, IL 60123";
var website_address = "4041 MacArthur Blvd, Suite 210, Newport Beach, CA. 92660";
var website_email = "info@unitedstatesinsurance.com";

$(document).ready(function() {
	$(".agent_phone").text(ivr_phone.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3'));
	$(".website_phone").text(website_phone.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3'));
	$(".website_address").text(website_address);
	$(".website_email").text(website_email);
	var user_location = sessionStorage['user_location'];
	if(!user_location) {
		$.get("https://ipinfo.io", function(response) {
		    $("#user_location").html(response.city + ", " + response.region);
			sessionStorage['user_location'] = (response.city + ", " + response.region);
		}, "jsonp")
		.fail(function() {
			$("#user_location").html("");
		});
	}else {
		$("#user_location").html(user_location);
	}

	$("#get_quote").click(function() {
		$("#quote_form").submit();
	})

	var hasoffers_domain = "http://quantumads.go2cloud.org";
	$.getScript("https://media.go2speed.org/assets/js/dl.js");
});
